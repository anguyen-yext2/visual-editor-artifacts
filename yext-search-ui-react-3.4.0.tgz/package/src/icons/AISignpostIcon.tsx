import React from 'react';

/**
 * Default icon for the AI signpost.
 *
 * @public
 */
export function AISignpostIcon({ className }: { className?: string }): React.JSX.Element {
  return (
    <svg
      fill='none'
      viewBox='0 0 20 20'
      xmlns='http://www.w3.org/2000/svg'
      className={className}
      aria-hidden='true'
    >
      <path
        fill='currentColor'
        d='M16.5 2C17.3284 2 18 2.67157 18 3.5V16.5C18 17.3284 17.3284 18 16.5 18H3.5C2.67157 18 2 17.3284 2 16.5V3.5C2 2.67157 2.67157 2 3.5 2H16.5ZM6.73145 6L4.5 13.29H5.52051L6.04785 11.3906H8.60156L9.13867 13.29H10.1592L7.92773 6H6.73145ZM11.3262 6V6.83008H12.8545V12.46H11.3262V13.29H15.374V12.46H13.8457V6.83008H15.374V6H11.3262ZM8.36719 10.5996H6.28711L7.32715 6.86914L8.36719 10.5996Z'
      />
    </svg>
  );
}
